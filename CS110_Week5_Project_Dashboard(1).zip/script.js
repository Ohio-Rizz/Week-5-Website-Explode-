const fields = document.querySelectorAll("[data-save]");
const checks = document.querySelectorAll("[data-check]");
const exportStatus = document.getElementById("exportStatus");

function setStatus(message, isError = false) {
  exportStatus.textContent = message;
  exportStatus.style.color = isError ? "#fca5a5" : "var(--green)";
}

function collectData() {
  const data = { version: 1, exportedAt: new Date().toISOString(), fields: {}, checks: {} };
  fields.forEach(el => data.fields[el.dataset.save] = el.value);
  checks.forEach(el => data.checks[el.dataset.check] = el.checked);
  return data;
}

function applyData(data) {
  if (!data || typeof data !== "object") throw new Error("This file doesn't contain saved CS110 project data.");
  fields.forEach(el => {
    if (Object.prototype.hasOwnProperty.call(data.fields || {}, el.dataset.save)) {
      el.value = String(data.fields[el.dataset.save] ?? "");
      localStorage.setItem("cs110_" + el.dataset.save, el.value);
    }
  });
  checks.forEach(el => {
    if (Object.prototype.hasOwnProperty.call(data.checks || {}, el.dataset.check)) {
      el.checked = Boolean(data.checks[el.dataset.check]);
      localStorage.setItem("cs110_check_" + el.dataset.check, el.checked);
    }
  });
  updateProgress();
}

fields.forEach(el => {
  const key = "cs110_" + el.dataset.save;
  const saved = localStorage.getItem(key);
  if (saved !== null) el.value = saved;
  el.addEventListener("input", () => localStorage.setItem(key, el.value));
});

checks.forEach(el => {
  const key = "cs110_check_" + el.dataset.check;
  el.checked = localStorage.getItem(key) === "true";
  el.addEventListener("change", () => {
    localStorage.setItem(key, el.checked);
    updateProgress();
  });
});

function updateProgress() {
  const total = checks.length;
  const done = [...checks].filter(c => c.checked).length;
  const pct = total ? Math.round(done / total * 100) : 0;
  document.getElementById("completionPercent").textContent = pct + "%";
  document.getElementById("meterFill").style.width = pct + "%";
  document.getElementById("completionText").textContent = `${done} of ${total} checklist items complete`;
}
updateProgress();

// Download just the filled-in answers as a portable JSON backup.
document.getElementById("exportData").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(collectData(), null, 2)], {type:"application/json"});
  downloadBlob(blob, "cs110-saved-entries.json");
  setStatus("Saved answers exported as JSON.");
});

// Restore a previously exported JSON backup.
document.getElementById("importDataFile").addEventListener("change", async event => {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    applyData(data);
    setStatus("Saved entries imported. Your browser now has the restored answers.");
  } catch (err) {
    setStatus("Could not import that file: " + err.message, true);
  }
  event.target.value = "";
});

// Package all project files into a ZIP, plus a startup data file that restores the
// current entries when the exported website is opened. JSZip is loaded on demand.
document.getElementById("exportWebsite").addEventListener("click", async () => {
  const button = document.getElementById("exportWebsite");
  button.disabled = true;
  setStatus("Preparing website bundle…");
  try {
    if (!window.JSZip) {
      await loadScript("https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js");
    }
    const zip = new JSZip();
    const files = [
      "index.html", "styles.css", "script.js", "README.md",
      "week4/3d.html", "week4/TestNotes.txt",
      "week4/vendor/license.md", "week4/vendor/NOTICE.md", "week4/vendor/babylon.js",
      "week4/js/app.js", "week4/css/styles.css"
    ];
    for (const path of files) {
      const response = await fetch(new URL(path, document.baseURI));
      if (!response.ok) throw new Error(`Couldn't read ${path} (HTTP ${response.status}).`);
      const content = await response.arrayBuffer();
      zip.file(path, content);
    }
    // The exported index reads this file at startup and seeds its localStorage.
    zip.file("saved-entries.json", JSON.stringify(collectData(), null, 2));
    zip.file("EXPORTED-WITH-SAVED-ENTRIES.txt",
      "This website bundle includes the saved form fields and checklist state in saved-entries.json.\\n" +
      "Open index.html in a browser. The website restores those values into that browser's local storage.\\n");
    const blob = await zip.generateAsync({type:"blob", compression:"DEFLATE", compressionOptions:{level:6}});
    downloadBlob(blob, "CS110_Week5_Website_With_Saved_Entries.zip");
    setStatus("Full website ZIP exported with your current entries and checklist.");
  } catch (err) {
    setStatus("Website export failed: " + err.message + " Try opening the site through a local web server and retry.", true);
  } finally {
    button.disabled = false;
  }
});

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Could not load the ZIP library. Check your internet connection and retry."));
    document.head.appendChild(script);
  });
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

document.getElementById("clearData").addEventListener("click", () => {
  if (!confirm("Clear all saved CS110 entries and checklist states on this browser?")) return;
  [...fields, ...checks].forEach(el => localStorage.removeItem("cs110_" + (el.dataset.save || "check_" + el.dataset.check)));
  location.reload();
});

window.addEventListener("scroll", () => {
  const max = document.documentElement.scrollHeight - innerHeight;
  document.getElementById("progressBar").style.width = (max ? scrollY / max * 100 : 0) + "%";
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) e.target.classList.add("in-view");
  });
}, {threshold:.08});
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

// If this copy was exported with a data file, restore its saved form values.
// fetch() may be blocked when opening file:// pages; a file:// fallback is handled
// by asking the user to import the bundled JSON manually when browser security blocks it.
(async function restoreBundledData() {
  try {
    const response = await fetch(new URL("saved-entries.json", document.baseURI));
    if (response.ok) {
      const data = await response.json();
      if (data && data.fields && data.checks) {
        applyData(data);
        setStatus("Saved entries from the exported website bundle are loaded.");
      }
    }
  } catch (_) {
    // On browsers that block local file fetches, use the built-in Import saved answers button.
  }
})();
