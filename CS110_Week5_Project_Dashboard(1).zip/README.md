# CS110 Week 5 Project Dashboard

Open `index.html` in a browser.

## Export and backup
- **Export full website + entries** creates a ZIP of the complete site, including the Week 4 3D scene, with your current form answers and checklist in `saved-entries.json`.
- **Export answers (JSON)** downloads a lightweight backup of your fields and checklist.
- **Import saved answers** restores a JSON backup in the browser.
- Full website ZIP creation uses JSZip loaded from a CDN, so an internet connection is required for that export action.

## Included
- Week 1–4 visual recap with four stops and diagrams
- Editable project fields for 5A/5B
- Embedded Week 4 Babylon.js 3D scene from the supplied starter
- R4 testing and Discord evidence fields
- R5 repository/submission checklist
- Browser-local autosave using localStorage
- Responsive layout and keyboard-focus styling
- The original local Babylon.js vendor files and license/notice files

## Important
Form entries are saved in the browser where you enter them. They are not automatically uploaded to GitHub or Canvas. The exported ZIP contains a JSON copy of the current entries. If the browser blocks loading that JSON when opening `index.html` directly from the ZIP, use **Import saved answers** and select `saved-entries.json` from the extracted folder.
