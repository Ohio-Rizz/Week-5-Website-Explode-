# CS110 Week 5 Project Dashboard

Open `index.html` in a browser. The **Export full website + entries** button creates a ZIP containing all site files, the Week 4 3D scene, and your current entries/checklist in `saved-entries.json`. This ZIP export is built in and works offline without a CDN. Use Export Answers (JSON) for a data backup or Import Saved Answers to restore it. Entries remain browser-local and are not uploaded to Canvas/GitHub.
