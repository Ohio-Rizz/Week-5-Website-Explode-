"use strict";

const canvas = document.getElementById("renderCanvas");
const statusText = document.getElementById("scene-status");
const resetButton = document.getElementById("reset-view");
const explodeButton = document.getElementById("explode-sphere");
const reassembleButton = document.getElementById("reassemble-sphere");
let engine;

function createScene() {
  const scene = new BABYLON.Scene(engine);
  scene.clearColor = new BABYLON.Color4(0.045, 0.065, 0.12, 1);

  const camera = new BABYLON.FreeCamera("camera1", new BABYLON.Vector3(0, 5, -10), scene);
  camera.setTarget(BABYLON.Vector3.Zero());
  camera.attachControl(canvas, true);
  camera.speed = 0.25;

  const light = new BABYLON.HemisphericLight("light", new BABYLON.Vector3(0, 1, 0), scene);
  light.intensity = 0.95;
  const glow = new BABYLON.PointLight("sphereGlow", new BABYLON.Vector3(0, 3, -2), scene);
  glow.intensity = 0.45;

  const sphere = BABYLON.MeshBuilder.CreateSphere("themeObject", { diameter: 2, segments: 32 }, scene);
  sphere.position.y = 1;
  const sphereMat = new BABYLON.StandardMaterial("sphereMaterial", scene);
  sphereMat.diffuseColor = new BABYLON.Color3(0.28, 0.55, 1);
  sphereMat.specularColor = new BABYLON.Color3(0.8, 0.9, 1);
  sphereMat.emissiveColor = new BABYLON.Color3(0.04, 0.12, 0.3);
  sphere.material = sphereMat;

  const ground = BABYLON.MeshBuilder.CreateGround("ground", { width: 7, height: 7 }, scene);
  const groundMat = new BABYLON.StandardMaterial("groundMaterial", scene);
  groundMat.diffuseColor = new BABYLON.Color3(0.08, 0.12, 0.22);
  groundMat.specularColor = BABYLON.Color3(0.12, 0.16, 0.25);
  ground.material = groundMat;

  // Build small fragments positioned on the sphere surface. They animate outward on click.
  const fragments = [];
  const fragmentMat = new BABYLON.StandardMaterial("fragmentMaterial", scene);
  fragmentMat.diffuseColor = new BABYLON.Color3(0.38, 0.68, 1);
  fragmentMat.emissiveColor = new BABYLON.Color3(0.08, 0.2, 0.48);
  fragmentMat.specularColor = new BABYLON.Color3(0.9, 0.95, 1);
  const count = 120;
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < count; i++) {
    const y = 1 - (i / (count - 1)) * 2;
    const radius = Math.sqrt(1 - y * y);
    const theta = goldenAngle * i;
    const direction = new BABYLON.Vector3(Math.cos(theta) * radius, y, Math.sin(theta) * radius).normalize();
    const size = 0.12 + Math.random() * 0.055;
    const piece = BABYLON.MeshBuilder.CreatePolyhedron("fragment" + i, { type: 1, size }, scene);
    piece.material = fragmentMat;
    const home = sphere.position.add(direction.scale(0.92));
    piece.position.copyFrom(home);
    piece.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
    piece.setEnabled(false);
    fragments.push({ mesh: piece, home: home.clone(), destination: home.add(direction.scale(1.8 + Math.random() * 2.2)), direction });
  }

  let animating = false;
  let exploded = false;
  let activeAnimations = [];

  function animateFragments(toExploded) {
    if (animating) return;
    animating = true;
    exploded = toExploded;
    sphere.setEnabled(false);
    activeAnimations.forEach(a => scene.stopAnimation(a));
    activeAnimations = [];
    fragments.forEach((fragment, index) => {
      const mesh = fragment.mesh;
      mesh.setEnabled(true);
      const target = toExploded ? fragment.destination : fragment.home;
      const animation = new BABYLON.Animation("fragmentMove" + index, "position", 60, BABYLON.Animation.ANIMATIONTYPE_VECTOR3, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
      animation.setKeys([
        { frame: 0, value: mesh.position.clone() },
        { frame: 36, value: target.clone() }
      ]);
      const easing = new BABYLON.CubicEase();
      easing.setEasingMode(BABYLON.EasingFunction.EASINGMODE_EASEOUT);
      animation.setEasingFunction(easing);
      mesh.animations = [animation];
      activeAnimations.push(mesh);
      scene.beginAnimation(mesh, 0, 36, false, 1, () => {
        if (index === fragments.length - 1) {
          animating = false;
          if (!exploded) {
            fragments.forEach(f => f.mesh.setEnabled(false));
            sphere.setEnabled(true);
          }
          statusText.textContent = exploded ? "Sphere exploded — click Reassemble to bring it back." : "Sphere reassembled.";
        }
      });
    });
    statusText.textContent = toExploded ? "Breaking the sphere into fragments…" : "Reassembling the sphere…";
  }

  explodeButton.addEventListener("click", () => {
    if (!exploded && !animating) animateFragments(true);
  });
  reassembleButton.addEventListener("click", () => {
    if (exploded && !animating) animateFragments(false);
  });
  resetButton.addEventListener("click", () => {
    camera.position.set(0, 5, -10);
    camera.setTarget(BABYLON.Vector3.Zero());
    statusText.textContent = "Camera reset to the starting view.";
  });

  return scene;
}

try {
  if (!window.BABYLON || !BABYLON.Engine.isSupported()) throw new Error("Babylon.js or WebGL is unavailable.");
  engine = new BABYLON.Engine(canvas, true);
  const scene = createScene();
  engine.runRenderLoop(() => scene.render());
  window.addEventListener("resize", () => engine.resize());
  resetButton.disabled = false;
  explodeButton.disabled = false;
  reassembleButton.disabled = false;
  statusText.textContent = "Scene ready — click Explode sphere to see the fragments fly apart.";
  console.log("CS110 Week 4: interactive 3D scene loaded.");
} catch (error) {
  if (engine) engine.dispose();
  canvas.hidden = true;
  statusText.textContent = "The 3D view could not start. Keep the week4 folder together and check the browser console.";
  console.error("Scene startup:", error);
}
