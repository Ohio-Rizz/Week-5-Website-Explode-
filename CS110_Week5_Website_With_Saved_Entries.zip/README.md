# CS110 Week 5 Project Dashboard

Open `index.html` in a browser.

- Form entries autosave in this browser's local storage.
- **Export full website + entries** creates a ZIP containing the website and current answers/checklist.
- The exported `index.html` embeds the current answers so they restore even when opened directly from a local folder.
- **Export answers (JSON)** and **Import saved answers** are also available.
- The full-site exporter works offline.

Entries remain in this browser and are not automatically uploaded to GitHub or Canvas.
